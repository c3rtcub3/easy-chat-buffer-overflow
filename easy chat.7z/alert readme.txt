modify the 8142 and follow my manual steps 


1. find out exception

2. check seh chain

3. break points

4. control seh 

5.  bad chars

6 . boom!!